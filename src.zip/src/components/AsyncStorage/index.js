export default{
    customer_id:'Customer_id',
    firstname:'firstname',
    lastname:'lastname',
    email:'email',
    telephone:'telephone',
    location:'location',
    store_id:'store_id',
    lat:'lat',
    long:'long'
}