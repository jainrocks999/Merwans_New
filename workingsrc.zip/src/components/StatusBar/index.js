import React from "react";
import { StatusBar } from "react-native";

export default (Status) => {
  return (<StatusBar barStyle="dark-content" backgroundColor='white'
   />
  )
};
