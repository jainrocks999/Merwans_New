export default BASEURLS = {
    // MainUrl:'https://demo.webshowcase-india.com/indiadeposit/public/apis/',
    // MainUrl: 'https://api.myjeweller.in/api/Partner/',
     //MainUrl1:'https://api.myjeweller.in/api/Supplier/',
    // MainUrl2:'https://api.myjeweller.in/api/User/',
     MainUrl:'https://merwans.co.in/index.php?route=api/',
     
};
// devappapi.olocker.in  api.myjeweller.in